
conf = {
   'input': '/home/input',
   'output': '/home/output'
}
