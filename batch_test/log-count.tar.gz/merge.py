# -*- coding: utf-8 -*-

import os
from conf  import conf
import json


total_file_path = '%s/total.txt' % conf['input']

input_path = '%s/count_results' % conf['input']
input_file = '%s/%s.json'

output_path = '%s/merge_result.json' % conf['output']


def main():

    # 1. get total
    total = 0
    with open(total_file_path) as f:
        total = int(f.read())


    # 2. parse, calculate
    m = {
        'INFO': 0,
        'WARN': 0,
        'ERROR': 0,
        'DEBUG': 0
    }
    for i in range(0,total):
        with open(input_file % (input_path, i)) as f:
            obj = json.loads(f.read())

        for (k,v) in obj.items():
            m[k] += v

    print('merge:')
    print(m)


    with open(output_path, 'w') as f:
        f.write(json.dumps(m))


if __name__ == '__main__':
    main()
