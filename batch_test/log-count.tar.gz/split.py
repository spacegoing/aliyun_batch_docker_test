# -*- coding: utf-8 -*-

import os
from conf import conf

input_path = '%s/log-count-data.txt' % conf['input']
output_path = '%s/split_results' % conf['output']
total_file_path = '%s/total.txt' % conf['output']

part_name = '%s/%s.txt'

def truncateDataFile(filename):
    if(os.path.exists(filename)):
        ouputFile = open(filename, 'w')
        ouputFile.truncate()
        ouputFile.close()


def main():

    if not os.path.exists(output_path):
        os.mkdir(output_path)

    c=0
    num = 0

    inputFile = open(input_path, 'r')

    truncateDataFile(part_name % ( output_path, num ))

    outputFile = open(part_name % ( output_path, num ), 'a')

    while True:
        line = inputFile.readline()

        if not line:
            break

        if c < 3500:
            outputFile.write('%s' % line)
        else:
            outputFile.close()
            c=0
            num+=1
            truncateDataFile(part_name % ( output_path, num ))
            outputFile = open(part_name % ( output_path, num ), 'a')
            outputFile.write('%s' % line)
        c+=1

    inputFile.close()
    outputFile.close()

    total = num+1
    print('split done, got total file: %s ' % total)

    with open(total_file_path, 'w') as f:
        f.write('%s' % total)


if __name__ == '__main__':
  main()


