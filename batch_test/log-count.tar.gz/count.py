# -*- coding: utf-8 -*-

import os
from conf import conf
import re
import json

# instance_id: get form environment variable, should start from 0
instance_id = os.environ['BATCH_COMPUTE_DAG_INSTANCE_ID']

input_path = '%s/split_results/%s.txt' % (conf['input'], instance_id)

output_path = '%s/count_results' % conf['output']
output_file = '%s/%s.json' % (output_path, instance_id)


def main():

    if not os.path.exists(output_path):
        os.mkdir(output_path)

    with open(input_path) as f:
        txt = f.read()

    m = {
        'INFO': 0,
        'WARN': 0,
        'ERROR': 0,
        'DEBUG': 0
    }


    # count
    for k in m:
       m[k] = len(re.findall(k, txt))

    print(m)

    with open(output_file, 'w') as f:
        f.write(json.dumps(m))


if __name__ == '__main__':
    main()
